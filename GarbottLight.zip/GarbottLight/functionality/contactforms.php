<?php
/*-----------------------------------------
>>> Menu Page Learning 
------------------------------------------*/
/*

function so3902760_wp_admin_menu() {

    // Register the parent menu.
    add_menu_page(
        __( 'Contact Forms', 'textdomain' )
        , __( 'Contact Forms', 'textdomain' )
        , 'manage_options'
        , 'contact_form_submissions'
        , 'display_my_menu'
    );

    // Register a submenu.
    add_submenu_page(
        'contact_forms' // Use the parent slug as usual.
        , __( 'View', 'textdomain' )
        , ''
        , 'manage_options'
        , 'my_hidden_submenu'
        , 'display_my_submenu'
    );
}
add_action( 'admin_menu', 'so3902760_wp_admin_menu' );








*/